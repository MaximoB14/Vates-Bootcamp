package com.company;

import java.util.LinkedHashSet;
import java.util.Set;

public class Plan {
    private String nombre;
    private float deuda;
    private int cuotas;
    private Set<Pago> pagos;

    private String listado;
    private int i;


    public Plan(String nombre, float deuda, int cuotas) {
        this.nombre = nombre;
        this.deuda = deuda;
        this.cuotas = cuotas;
        pagos = new LinkedHashSet<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getDeuda() {
        return deuda;
    }

    public void setDeuda(float deuda) {
        this.deuda = deuda;
    }

    public int getCuotas() {
        return cuotas;
    }

    public void setCuotas(int cuotas) {
        this.cuotas = cuotas;
    }

    public Set<Pago> getPagos() {
        return pagos;
    }

    @Override
    public String toString() {
        return "Plan | " + "Nombre: " + nombre + " | Deuda: " + deuda + " | Cuotas: " + cuotas + " |";
    }

    public void agregarPago(Pago p){
        pagos.add(p);
    }

    public boolean estaPagadoTotalmente(){
        return cuotas == pagos.size();
    }

    public String listadoPagos(){
        listado = "Contribuyente: " + nombre + "\nCuotas Pagadas: " + pagos.size() + "\n";
        i = 1;
        pagos.stream().forEach(pago -> {listado = listado.concat(Integer.toString(i) + pago)+"\n"; i++;});
        return listado;

    }

    public float sumaInteresesCobrados(){
        return pagos.stream().reduce(0f, (interesesCobrados, plan) -> interesesCobrados + plan.getInteresesAdicionales(), (a,b) -> b);
    }

}
