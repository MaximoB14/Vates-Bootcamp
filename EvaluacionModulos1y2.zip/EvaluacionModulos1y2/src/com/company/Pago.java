package com.company;

public class Pago {
    private static final float interesDiario = 0.5f;
    private float importe;
    private int demora;
    private float interesesAdicionales;

    public Pago(float importe, int demora) {
        this.importe = importe;
        this.demora = demora;
        actInteresesAdicionales();
    }
    public float getImporte() {
        return importe;
    }

    public void setImporte(float importe) {
        this.importe = importe;
        actInteresesAdicionales();
    }

    public int getDemora() {
        return demora;
    }

    public void setDemora(int demora) {
        this.demora = demora;
        actInteresesAdicionales();
    }

    public float getInteresesAdicionales() {
        return interesesAdicionales;
    }

    public void actInteresesAdicionales() {
        interesesAdicionales = importe * demora * interesDiario / 100;
    }

    @Override
    public String toString() {
        return " | Pago | Importe: " + importe + " | Demora: " + demora + " | Intereses Adicionales: " + interesesAdicionales + " |";
    }
}
