package com.company;

import java.util.Locale;
import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        System.out.println("\n---Evaluación Módulos 1 y 2-------\n---Programa Municipalidad---------\n---Realizado por Máximo Becerra---\n" +
                "(Los float se cargan con , por ende para tener 20.5f se carga como 20,5)");
        Scanner sc = new Scanner(System.in);

        Municipalidad muni = new Municipalidad();

        String nombre;
        float deuda;
        int cuotas;
        Plan plan;
        float importe;
        int demora;
        Pago pago;

        String opcionPlan;
        String opcionPago;

        System.out.println("\n¿Desea crear un nuevo plan? Y/n");
        opcionPlan = sc.next().toLowerCase();

        while (opcionPlan.equals("y")){
            System.out.println("Creando nuevo plan\nIngrese");
            System.out.print("Nombre: ");
            nombre = sc.next();
            System.out.print("Deuda: ");
            deuda = sc.nextFloat();
            System.out.print("Cuotas: ");
            cuotas = sc.nextInt();

            plan = new Plan(nombre, deuda, cuotas);

            System.out.println("\n¿Desea registrar un nuevo pago? Y/n");
            opcionPago = sc.next().toLowerCase();

            while (opcionPago.equals("y")){
                System.out.println("Creando nuevo pago para " + nombre + "\nIngrese");
                System.out.print("Importe: ");
                importe = sc.nextFloat();
                System.out.print("Demora: ");
                demora = sc.nextInt();

                pago = new Pago(importe, demora);
                plan.agregarPago(pago);

                if (plan.getPagos().size() == cuotas){
                    System.out.println("Se registraron todos los pagos");
                    break;
                }
                else {
                    System.out.println("\n¿Desea registrar un nuevo pago? Y/n");
                    opcionPago = sc.next().toLowerCase();
                }
            }
            muni.agregarPlan(plan);
            System.out.println("\n¿Desea crear un nuevo plan? Y/n");
            opcionPlan = sc.next().toLowerCase();
        }

        System.out.println("------Procesando-------");
        System.out.println("Cantidad de planes pagados en su totalidad: " + muni.cantPlanesPagados());
        System.out.println("Sumatoria de las deudas registradas: " + muni.sumatoriaDeuda());
        System.out.println("Promedio general de intereses adicionales cobrados: " + muni.promedioIntereses());

        String opcionBusqueda;

        System.out.println("\n¿Desea listar todos los pagos registrados de un contribuyente en particular? Y/n");
        opcionBusqueda = sc.next().toLowerCase();
        while (opcionBusqueda.equals("y")){
            System.out.print("Ingrese nombre del contribuyente: ");
            nombre = sc.next();
            System.out.println("\n"+ muni.listadoPagosContribuyente(nombre));

            System.out.println("¿Desea listar todos los pagos de otro contribuyente? Y/n");
            opcionBusqueda = sc.next().toLowerCase();
        }
    }
}
