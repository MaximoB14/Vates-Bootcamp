package com.company;

import java.util.Set;
import java.util.LinkedHashSet;

public class Municipalidad {
    private Set<Plan> planes;

    public Municipalidad() {
        planes = new LinkedHashSet<>();
    }

    public void agregarPlan(Plan p){
        planes.add(p);
    }

    public int cantPlanesPagados(){
        return (int) planes.stream().filter(Plan::estaPagadoTotalmente).count();
    }

    public float sumatoriaDeuda(){
        return planes.stream().reduce(0f, (sumDeudas, plan) -> sumDeudas+plan.getDeuda(), (a, b) -> b);
    }

    public String listadoPagosContribuyente(String nombre){
        return planes.stream().filter(plan -> plan.getNombre().equals(nombre)).
                reduce("", (listado, plan) -> listado.concat(plan.listadoPagos()), (a,b) -> b );
    }

    public float promedioIntereses(){
        Set<Pago> pagos = new LinkedHashSet<>();
        planes.stream().forEach(plan -> pagos.addAll(plan.getPagos()));
        return (float) pagos.stream().filter(pago -> pago.getInteresesAdicionales() > 0).
                mapToDouble(Pago::getInteresesAdicionales).average().orElse(0);
    }
}
