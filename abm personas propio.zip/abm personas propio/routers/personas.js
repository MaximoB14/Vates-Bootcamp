const express = require('express')
const gestor_personas = require('../gestores/personas')
const router = express.Router()

router.use(express.json())

//Consultar Una
router.get("/:documento", async (req, res) => {
    let documento = parseInt(req.params.documento)
    
    if (!isNaN(documento)) { // Si no es NaN, es porque es un número correcto
        let persona_encontrada = await gestor_personas.consultarUna(documento) 

        if (persona_encontrada) 
            res.json(persona_encontrada)
        else
            res.status(404)
    }
    else {
        res.status(400).send("El parámetro debe ser numérico")
    }
    res.end()
})

//Consular Todas
router.get("/", async (req, res) => {
    res.json(await gestor_personas.consultarTodas())
    res.end()
})

//Agregar
router.post("", async (req, res) => {
    let persona = req.body
    let documento = persona.documento
    let persona_encontrada = await gestor_personas.consultarUna(documento)

    if (persona_encontrada) {
        res.status(400).send("Persona con dicho documento ya existe")
    }
    else{
        await gestor_personas.agregar(persona)
        res.sendStatus(201)
    }

})

//Modificar
router.put("/:documento", async (req, res) => {
    let documento = parseInt(req.params.documento)
    
    if (!isNaN(documento)) {
        let persona = req.body
        let persona_encontrada = await gestor_personas.consultarUna(documento)

        if (persona_encontrada) {
            await gestor_personas.modificar(documento, persona)
            res.sendStatus(200)
        }
        else {
            res.sendStatus(404)
        }
    }
    else {
        res.status(400).send("El parámetro debe ser numérico")
    }
    res.end()
})

//Borrar

router.delete("/:documento", async (req, res) =>{
    let documento = parseInt(req.params.documento)

    if (!isNaN(documento)) {
        let persona_encontrada = await gestor_personas.consultarUna(documento)

        if (persona_encontrada) {
            await gestor_personas.borrar(documento)
            res.sendStatus(200)
        }
        else {
            res.sendStatus(404)
        }
    }
    else {
        res.status(400).send("El parámetro debe ser numérico")
    }
    res.end()
})


exports.router = router