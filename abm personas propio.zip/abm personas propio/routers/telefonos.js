const express = require('express')
const gestor_telefonos = require('../gestores/telefonos')
const gestor_personas = require('../gestores/personas')
const router = express.Router()

router.use(express.json())

//Consultar Uno
router.get("/:id_telefono", async (req, res) => {
    let id_telefono = parseInt(req.params.id_telefono)
    
    if (!isNaN(id_telefono)) { // Si no es NaN, es porque es un número correcto
        let telefono_encontrado = await gestor_telefonos.consultarUno(id_telefono) 

        if (telefono_encontrado) 
            res.json(telefono_encontrado)
        else
            res.status(404)
    }
    else {
        res.status(400).send("El parámetro debe ser numérico")
    }
    res.end()
})

//Consular Todos
router.get("/", async (req, res) => {
    res.json(await gestor_telefonos.consultarTodos())
    res.end()
})

//Agregar
router.post("", async (req, res) => {
    let telefono = req.body
    let documento = telefono.documento
    let persona_encontrada = await gestor_personas.consultarUna(documento)

    if (persona_encontrada) {        
        await gestor_telefonos.agregar(telefono)
        res.sendStatus(201)
    
    }
    else{
        res.status(400).send("No existe persona con ese documento")
    }

})

//Modificar
router.put("/:id_telefono", async (req, res) => {
    let id_telefono = parseInt(req.params.id_telefono)
    
    if (!isNaN(id_telefono)) {
        let telefono = req.body
        let telefono_encontrado = await gestor_telefonos.consultarUno(id_telefono)

        if (telefono_encontrado) {
            await gestor_telefonos.modificar(id_telefono, telefono)
            res.sendStatus(200)
        }
        else {
            res.sendStatus(404)
        }
    }
    else {
        res.status(400).send("El parámetro debe ser numérico")
    }
    res.end()
})

//Borrar

router.delete("/:id_telefono", async (req, res) =>{
    let id_telefono = parseInt(req.params.id_telefono)

    if (!isNaN(id_telefono)) {
        let telefono_encontrado = await gestor_telefonos.consultarUno(id_telefono)

        if (telefono_encontrado) {
            await gestor_telefonos.borrar(id_telefono)
            res.sendStatus(200)
        }
        else {
            res.sendStatus(404)
        }
    }
    else {
        res.status(400).send("El parámetro debe ser numérico")
    }
    res.end()
})


exports.router = router