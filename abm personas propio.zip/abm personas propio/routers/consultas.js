const express = require('express')
const gestor_consultas = require('../gestores/consultas')
const gestor_personas = require('../gestores/personas')
const gestor_telefonos = require('../gestores/telefonos')
const router = express.Router()

//Consultar los telefonos de una persona
router.get("/personas/:documento/telefonos", async (req, res) => {
    let documento = parseInt(req.params.documento)
    
    if (!isNaN(documento)) { // Si no es NaN, es porque es un número correcto
        let telefono_encontrado = await gestor_personas.consultarUna(documento) 

        if (telefono_encontrado) 
            res.json(await gestor_consultas.telefonosPersona(documento))
        else
            res.status(404)
    }
    else {
        res.status(400).send("El parámetro debe ser numérico")
    }
    res.end()
})

//Consultar los telefonos de una persona filtrado por tipo
router.get("/personas/:documento/telefonos/:id_tipo", async (req, res) => {
    let documento = parseInt(req.params.documento)
    let id_tipo = parseInt(req.params.id_tipo)
    
    if (!isNaN(documento)) {
        let telefono_encontrado = await gestor_personas.consultarUna(documento) 

        if (telefono_encontrado) 
            res.json(await gestor_consultas.telefonosPersonaTipo(documento, id_tipo))
        else
            res.status(404)
    }
    else {
        res.status(400).send("El parámetro debe ser numérico")
    }
    res.end()
})

//Buscar telefonos por sufijo
router.get("/telefono/:sufijo", async (req, res) => {
    let sufijo = parseInt(req.params.sufijo)

    if (!isNaN(sufijo)) {
        res.json(await gestor_consultas.telefonosSufijo(sufijo))
        res.status(200)

    }
    else {
        res.status(400).send("El parámetro debe ser numérico")
    }
    res.end()
})

exports.router = router