const express = require("express")

const servidor = express()

const personas = require("./routers/personas")

const telefonos = require("./routers/telefonos")

const consultas = require("./routers/consultas")


servidor.use("/personas", personas.router)

servidor.use("/telefonos", telefonos.router)

servidor.use("", consultas.router)

servidor.listen(8080)