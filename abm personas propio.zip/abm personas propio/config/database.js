module.exports = {
    host: "localhost",
    database: "hola",
    user: "root",
    password: "1407"
}