const mariadb = require('mariadb')
const db = require("../config/database")

async function telefonosPersona(documento){
    const conn = await mariadb.createConnection(db)
    let telefonos = await conn.query("SELECT * FROM telefonos WHERE documento = ?", [documento])
    conn.end()
    return telefonos
}

async function telefonosPersonaTipo(documento, id_tipo){
    const conn = await mariadb.createConnection(db)
    let telefonos = await conn.query("SELECT * FROM telefonos WHERE documento = ? AND id_tipo = ?", [documento, id_tipo])
    conn.end()
    return telefonos
}

async function telefonosSufijo(sufijo){
    const conn = await mariadb.createConnection(db)
    let telefonos = await conn.query("SELECT * FROM telefonos WHERE numero LIKE '%?'", [sufijo])
    conn.end()
    return telefonos
}

exports.telefonosPersona = telefonosPersona
exports.telefonosPersonaTipo = telefonosPersonaTipo
exports.telefonosSufijo = telefonosSufijo