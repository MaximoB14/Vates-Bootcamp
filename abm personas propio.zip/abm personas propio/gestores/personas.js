const mariadb = require('mariadb')
const db = require("../config/database")


async function consultarUna(documento){
    const conn = await mariadb.createConnection(db)
    let persona = await conn.query("SELECT * FROM personas2 WHERE documento = ?", [documento])
    conn.end()
    return persona[0]
}

async function consultarTodas(){
    const conn = await mariadb.createConnection(db)
    let personas = await conn.query("SELECT * FROM personas2")
    conn.end()
    return personas
}

async function agregar(persona){
    const conn = await mariadb.createConnection(db)
    const datos = [persona.documento, persona.nombre, persona.apellido, persona.edad]
    await conn.query("INSERT INTO personas2(documento, nombre, apellido, edad) VALUES(?,?,?,?) ", datos)
    conn.end()
}

async function modificar(documento, persona){
    const conn = await mariadb.createConnection(db)
    const datos = [persona.nombre, persona.apellido, persona.edad, documento]
    await conn.query("UPDATE personas2 SET nombre = ?, apellido = ?, edad = ? WHERE documento = ?", datos)
    conn.end()
}

async function borrar(documento){
    const conn = await mariadb.createConnection(db)
    await conn.query("DELETE FROM personas2 WHERE documento = ?", [documento])
}

exports.consultarUna = consultarUna
exports.consultarTodas = consultarTodas
exports.agregar = agregar
exports.modificar = modificar
exports.borrar = borrar