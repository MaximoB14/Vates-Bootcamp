const mariadb = require('mariadb')
const db = require("../config/database")


async function consultarUno(id_telefono){
    const conn = await mariadb.createConnection(db)
    let telefono = await conn.query("SELECT * FROM telefonos WHERE id_telefono = ?", [id_telefono])
    conn.end()
    return telefono[0]
}

async function consultarTodos(){
    const conn = await mariadb.createConnection(db)
    let telefonos = await conn.query("SELECT * FROM telefonos")
    conn.end()
    return telefonos
}

async function agregar(telefono){
    const conn = await mariadb.createConnection(db)
    const datos = [telefono.numero, telefono.id_tipo, telefono.documento]
    await conn.query("INSERT INTO telefonos(numero, id_tipo, documento) VALUES(?,?,?) ", datos)
    conn.end()
}

async function modificar(id_telefono, telefono){
    const conn = await mariadb.createConnection(db)
    const datos = [telefono.numero, telefono.id_tipo, telefono.documento, id_telefono]
    await conn.query("UPDATE telefonos SET numero = ?, id_tipo = ?, documento = ? WHERE id_telefono = ?", datos)
    conn.end()
}

async function borrar(id_telefono){
    const conn = await mariadb.createConnection(db)
    await conn.query("DELETE FROM telefonos WHERE id_telefono = ?", [id_telefono])
}

exports.consultarUno = consultarUno
exports.consultarTodos = consultarTodos
exports.agregar = agregar
exports.modificar = modificar
exports.borrar = borrar