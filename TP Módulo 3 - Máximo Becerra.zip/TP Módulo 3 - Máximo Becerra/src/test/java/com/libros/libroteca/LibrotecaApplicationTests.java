package com.libros.libroteca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibrotecaApplicationTests {

	@Test
	void contextLoads() {
	}

}
