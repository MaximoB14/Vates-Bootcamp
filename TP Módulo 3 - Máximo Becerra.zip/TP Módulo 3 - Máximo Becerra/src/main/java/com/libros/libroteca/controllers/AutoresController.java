package com.libros.libroteca.controllers;

import com.libros.libroteca.entidades.Autor;
import com.libros.libroteca.serivicios.AutoresService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/autores")
public class AutoresController {

    @Autowired
    AutoresService service;

    @GetMapping("")
    public List<Autor> listarAutores(){
        return service.listarAutores();
    }

    @GetMapping("/{id}")
    public Autor listarUnAutor(@PathVariable Integer id){
        return service.buscarUnAutor(id);
    }

    @PutMapping("/")
    public void añadirAutor(@RequestParam String nombre){
        Autor autor = new Autor(nombre);
    }

    @DeleteMapping("/{id}")
    public void borrarAutor(@PathVariable Integer id){

    }
}
