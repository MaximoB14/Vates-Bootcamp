package com.libros.libroteca.entidades;

import javax.persistence.*;

@Entity
@Table(name = "autores")
public class Autor {
    @Id
    private Integer id;

    @Basic
    private String nombre;

    public Autor(String nombre) {
        this.nombre = nombre;
    }

    public Integer getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
