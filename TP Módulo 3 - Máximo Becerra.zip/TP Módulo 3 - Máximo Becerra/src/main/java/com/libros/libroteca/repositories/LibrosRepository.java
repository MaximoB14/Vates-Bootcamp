package com.libros.libroteca.repositories;

import com.libros.libroteca.entidades.Libro;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LibrosRepository extends JpaRepository<Libro, Integer> {
    List<Libro> getGetAllByOrderByTitulo();
    List<Libro> getAllByTitulo(String titulo);

}
