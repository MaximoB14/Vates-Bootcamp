package com.libros.libroteca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibrotecaApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibrotecaApplication.class, args);
	}

}
