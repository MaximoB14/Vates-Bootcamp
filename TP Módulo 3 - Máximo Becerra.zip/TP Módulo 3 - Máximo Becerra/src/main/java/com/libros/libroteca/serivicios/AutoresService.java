package com.libros.libroteca.serivicios;

import com.libros.libroteca.entidades.Autor;
import com.libros.libroteca.repositories.AutoresRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.annotation.ApplicationScope;

import java.util.List;

@Service
@ApplicationScope
public class AutoresService {

    @Autowired
    AutoresRepository repository;

    public void guardarAutor(Autor autor){
        repository.save(autor);
    }

    public Autor buscarUnAutor(Integer id){
        return repository.findById(id).orElse(null);
    }

    public List<Autor> listarAutores(){
        return repository.findAll();
    }

    public void borrarAutor(Integer id){
        repository.deleteById(id);
    }

}
