package com.libros.libroteca.serivicios;

import com.libros.libroteca.entidades.Libro;
import com.libros.libroteca.repositories.LibrosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.annotation.ApplicationScope;

import java.util.List;

@Service
@ApplicationScope
public class LibrosService {
    @Autowired
    private LibrosRepository repository;

    public void guardarLibro(Libro libro){
        repository.save(libro);
    }

    public Libro buscarUnLibro(Integer id){
        return repository.findById(id).orElse(null);
    }

    public List<Libro> listarLibros(){
        return repository.findAll();
    }

    public void borrarLibro(Integer id){
        repository.deleteById(id);
    }

    public List<Libro> listarLibrosOrdenadosPorTitulo(){
        return repository.getGetAllByOrderByTitulo();
    }

    public List<Libro> listarLibrosPorTitulo(String titulo){
        return repository.getAllByTitulo(titulo);
    }

}
