package com.libros.libroteca.controllers;

import com.libros.libroteca.entidades.Autor;
import com.libros.libroteca.entidades.Libro;
import com.libros.libroteca.serivicios.AutoresService;
import com.libros.libroteca.serivicios.LibrosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/libros")
public class LibrosController {
    @Autowired
    private LibrosService service;
    private AutoresService serviceAutor;

    @GetMapping("")
    public List<Libro> listarLibros(){
        return service.listarLibros();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Libro> listarUnLibro(@PathVariable Integer id){
        Libro encontrado = service.buscarUnLibro(id);
        if(encontrado != null){
            return ResponseEntity.ok(encontrado);
        }
        else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/")
    public void añadirLibro(@RequestParam(defaultValue = "") String titulo, @RequestParam(defaultValue = "") Integer id_autor){
        Autor autor = serviceAutor.buscarUnAutor(id_autor);
        Libro libro = new Libro(titulo, autor);
        service.guardarLibro(libro);
    }

    @DeleteMapping("/{id}")
    public void borrarLibro(@PathVariable Integer id){
        service.borrarLibro(id);
    }

    @GetMapping("/titulo/")
    public List<Libro> listarLibrosOrdernadosPorTitulo(){
        return service.listarLibrosOrdenadosPorTitulo();
    }

    @GetMapping("/titulo/{titulo}")
    public List<Libro> listarLibrosPorTitulo(@PathVariable String titulo){
        return service.listarLibrosPorTitulo(titulo);
    }
}
